def Read_Dictionary():
    LapFiles = open("item.txt", "r")
    DatabaseofLaptop = {}
    idof_laptop = 1
    for line_num in LapFiles:
        line_num = line_num.replace("\n", "")
        DatabaseofLaptop.update({idof_laptop: line_num.split(",")})
        idof_laptop = idof_laptop + 1
    LapFiles.close()
    return DatabaseofLaptop

def Bill_forCustomer():
    print("-----------------------------------------------------------------------------------------------------------------------------")
    print("Enter your details for the bill: ")
    print("-----------------------------------------------------------------------------------------------------------------------------")
    print("\n")
    customer_name = input("Enter Customer's Name: ")
    print("\n")
    Phone_Number = input("Enter Customer's Phone Number: ")
    print("\n")
    print("-----------------------------------------------------------------------------------------------------------------------------")
    print("\n")
    return customer_name, Phone_Number

def Generated_Bills():
    print("-----------------------------------------------------------------------------------------------------------------------------")
    print("Enter your details for the bill: ")
    print("-----------------------------------------------------------------------------------------------------------------------------")
    print("\n")
    customer_name = input("Enter Distributor's Name: ")
    print("\n")
    Phone_Number = input("Enter Distributor's Phone Number: ")
    print("\n")
    print("-----------------------------------------------------------------------------------------------------------------------------")
    print("\n")
    return customer_name, Phone_Number