from .ReaD import *

def valid_LapID():
    DatabaseofLaptop = Read_Dictionary()
    Matched_ID = int(input("Please Provide the LaptopID  you want to buy: "))
    while Matched_ID <= 0 or Matched_ID > len(DatabaseofLaptop):

        print("Please! provide a valid Laptop ID !!!")

        print("\n")

        Matched_ID = int(input("Please enter the LaptopID :"))
    return Matched_ID

def Quantity_Valid(Matched_ID):
    DatabaseofLaptop = Read_Dictionary()
    get_quantity = DatabaseofLaptop[Matched_ID][3]
    Chosen_Amount = int(
            input("Please Enter the quantity of the laptop that you want to buy: "))

    while Chosen_Amount <= 0 or Chosen_Amount > int(get_quantity):

        print("The number of laptop you are looking for is not available in our shop RIghtnow. Please check  and try again.")

        print("\n")

        Chosen_Amount = int(
            input("Enter the number of laptop you want to buy: "))
    return Chosen_Amount
