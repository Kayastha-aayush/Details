from Van.ReaD import *

def Changed_Quantity_Laptops(Matched_ID, Chosen_Amount):
    DatabaseofLaptop = Read_Dictionary()
    DatabaseofLaptop[Matched_ID][3] =  int(DatabaseofLaptop[Matched_ID][3])-int(Chosen_Amount)

    LapFiles = open(".\.\item.txt", "w")

    for value in DatabaseofLaptop.values():
        LapFiles.write(str(value[0])+","+str(value[1])+","+str(value[2])+","+str(value[3])+","+str(value[4])+","+str(value[5]))
        LapFiles.write("\n")
    LapFiles.close()

def Updated_Quantity_Laptops(Matched_ID, Chosen_Amount):
        
        DatabaseofLaptop = Read_Dictionary()

        DatabaseofLaptop[Matched_ID][3] =  int(DatabaseofLaptop[Matched_ID][3])+int(Chosen_Amount)

        LapFiles = open("item.txt", "w")

        for value in DatabaseofLaptop.values():
            LapFiles.write(str(value[0])+","+str(value[1])+","+str(value[2])+","+str(value[3])+","+str(value[4])+","+str(value[5]))
            LapFiles.write("\n")
        LapFiles.close()

def Modified_Bill1(customer_bought, CustomersName, Phone_Number):
            cost = 0
            ShippingCharge = 800
            for i in customer_bought:
                cost+=int(i[3])
            TotalCost =cost+ShippingCharge
            with open(str(CustomersName)+str(Phone_Number)+".txt", "w") as LapFiles:
                LapFiles.write("\n")
                LapFiles.write("\t \t \t \t Kamalpokhari International Laptop Centre ")
                LapFiles.write("\n")
                LapFiles.write("\t \t Putalisadak, kathmandu | Phone No: 9802144253 ")
                LapFiles.write("\n")
                LapFiles.write("-------------------------------------------------------------------------\n")
                LapFiles.write("Details of Available laptop:\n")
                LapFiles.write("-------------------------------------------------------------------------\n")
                LapFiles.write("Name of Costumer: "+str(CustomersName)+"\n")
                LapFiles.write("Phone number: "+str(Phone_Number)+"\n")
                LapFiles.write("-------------------------------------------------------------------------\n")
                LapFiles.write("\n")
                LapFiles.write("Details of purchase are:\n")
                LapFiles.write("------------------------------------------------------------------------------------------------------------------\n")
                LapFiles.write("Item Name \t\t Total Quantity \t\t Price Unit \tTotal\n")
                LapFiles.write("------------------------------------------------------------------------------------------------------------------\n")
                for i in customer_bought:
                    LapFiles.write(str(i[0])+"\t\t\t"+str(i[1])+"\t\t\t"+str(i[2])+"\t\t\t"+"$"+str(i[3])+"\n")
                LapFiles.write("------------------------------------------------------------------------------------------------------------------\n")
                LapFiles.write("\n")
                if ShippingCharge:
                    LapFiles.write("Your Shipping Cost is:"+""+str(ShippingCharge)+"\n")
                    LapFiles.write("\n")
                    LapFiles.write("Grand Total: $"+str(TotalCost)+"\n")
                    LapFiles.write("\n")
                    LapFiles.write("*************Note: The shipping cost is added to the grand cost**********"+"\n")
                    LapFiles.write("\n")
                else:
                    LapFiles.write("Grand Total: $"+str(TotalCost))
                print("\n")

        
def Modified_Bill2(customer_bought, CustomersName, Phone_Number, ShippingCharge):
            cost = 0
            
            for i in customer_bought:
                cost+=int(i[3])
            TotalCost =cost

            with open(str(CustomersName)+str(Phone_Number)+".txt", "w") as LapFiles:
                LapFiles.write("\n")
                LapFiles.write("\t \t \t \t Kamalpokhari International Laptop Centre ")
                LapFiles.write("\n")
                LapFiles.write("\t \t Hattiban , Lalitpur| Phone No: 9626306156 ")
               
                
                LapFiles.write("Details of laptop:\n")
                LapFiles.write("-------------------------------------------------------------------------\n")
                LapFiles.write("Name of the Costumer: "+str(CustomersName)+"\n")
                LapFiles.write("Contact number: "+str(Phone_Number)+"\n")
                LapFiles.write("-------------------------------------------------------------------------\n")
                LapFiles.write("\n")
                LapFiles.write("Details of purchase are:\n")
                LapFiles.write("------------------------------------------------------------------------------------------------------------------\n")
                LapFiles.write("Item Name \t\t Total Quantity \t\t Unit Price \tTotal\n")
                LapFiles.write("------------------------------------------------------------------------------------------------------------------\n")
                for i in customer_bought:
                    LapFiles.write(str(i[0])+"\t\t\t"+str(i[1])+"\t\t\t"+str(i[2])+"\t\t\t"+"$"+str(i[3])+"\n")
                LapFiles.write("------------------------------------------------------------------------------------------------------------------\n")
                LapFiles.write("\n")
                if ShippingCharge:
                    LapFiles.write("Your Shipping Cost is:"+""+str(ShippingCharge)+"\n")
                    LapFiles.write("\n")
                    LapFiles.write("Grand Total: $"+str(TotalCost)+"\n")
                    LapFiles.write("\n")
                    LapFiles.write("****Note: The shipping charge is added to the grand cost****"+"\n")
                    LapFiles.write("\n")
                else:
                    LapFiles.write("Grand Total: $"+str(TotalCost))
                print("\n")

def Edited_Bill(customer_bought, CustomersName, Phone_Number):
        cost = 0
        for i in customer_bought:
            cost+=int(i[3])
        TotalCost =cost+(0.13 * cost)
        
        with open(str(CustomersName)+str(Phone_Number)+".txt", "w") as LapFiles:
            LapFiles.write("\n")
            LapFiles.write("\t \t \t \t Kamalpokhari International Laptop Centre Bill ")
            LapFiles.write("\n")
            LapFiles.write("\t \t Putalisadak, kathmandu | Phone No: 9802144253 ")
            LapFiles.write("\n")
            LapFiles.write("-------------------------------------------------------------------------\n")
            LapFiles.write("Details of Available laptop:\n")
            LapFiles.write("-------------------------------------------------------------------------\n")
            LapFiles.write("Name of the Costumer: "+str(CustomersName)+"\n")
            LapFiles.write("Phone number: "+str(Phone_Number)+"\n")
            LapFiles.write("-------------------------------------------------------------------------\n")
            LapFiles.write("\n")
            LapFiles.write("Details of purchase are:\n")
            LapFiles.write("------------------------------------------------------------------------------------------------------------------\n")
            LapFiles.write("Item Name \t\t Total Quantity \t\t Price Unit \tTotal\n")
            LapFiles.write("------------------------------------------------------------------------------------------------------------------\n")
            for i in customer_bought:
                LapFiles.write(str(i[0])+"\t\t\t"+str(i[1])+"\t\t\t"+str(i[2])+"\t\t\t"+"$"+str(i[3])+"\n")
            LapFiles.write("------------------------------------------------------------------------------------------------------------------\n")
            LapFiles.write("\n")
            LapFiles.write("Your Shipping Cost is: 13%"+"\n")
            LapFiles.write("\n")
            LapFiles.write("Grand Total: $"+str(TotalCost)+"\n")
            LapFiles.write("\n")
            LapFiles.write("********Note: VAT is added to the grand cost********"+"\n")
            print("\n")