def Greetings():
    print("\n")
    print("\n")
    print("\t \t \t \t \t \t Kamalpokhari International Laptop Centre ")
    print("\n")
    print("\t \t \t \t \tPutalisadak, kathmandu | Phone No: 9802144253 ")
    print("\n")
    print("-------------------------------------------------------------------------------------------------------------------------")
    print("\t \t \t \t \tWelcome To Our laptop System!")
    print("-------------------------------------------------------------------------------------------------------------------------")
    print("\n")

def DisplayingLaptops():
    print("-------------------------------------------------------------------------------------------------------------------------")
    print("S.N. \t Name \t \t Brand \t\t Price \t Quantity \tProcessor \tGraphic Card ")
    print("-------------------------------------------------------------------------------------------------------------------------")

    LapFiles = open("item.txt", "r")
    a = 1
    for line_num in LapFiles:
        print(a, "\t"+line_num.replace(",", "\t"))
        a = a+1
    print("-------------------------------------------------------------------------------------------------------------------------")
    LapFiles.close()
    print("\n")

def Bill_1(custumer_bought, customer_name, Phone_Number):
            total = 0
            shippping_charge = 800
            for i in custumer_bought:
                total+=int(i[3])
            TotalCost =total+shippping_charge
            print("\n")
            print("\t \t \t \t Kamalpokhari International Laptop Centre Bill ")
            print("\n")
            print("\t \t Putalisadak, kathmandu | Phone No: 9802144253 ")
            print("\n")
            print("-------------------------------------------------------------------------")
            print("Details of laptop :")
            print("-------------------------------------------------------------------------")
            print("Customer's name:"+str(customer_name))
            print("Customer's phone number: "+str(Phone_Number))
            print("-------------------------------------------------------------------------")
            print("\n")
            print("Details of Purchase:")
            print("------------------------------------------------------------------------------------------------------------------")
            print("Item Name \t\t Total Quantity \t\t Unit Price \t\t\tTotal")
            print("------------------------------------------------------------------------------------------------------------------")
            for i in custumer_bought:
                print(i[0],"\t\t\t",i[1],"\t\t\t",i[2],"\t\t\t","$",i[3])
            print("------------------------------------------------------------------------------------------------------------------")
            if shippping_charge:
                print("Your Shipping Cost is:", shippping_charge)
                print("Grand Total: $"+str(TotalCost))
                print("Note: Shipping cost is added to the grand total")
            else:
                print("Grand Total: $"+str(TotalCost))
            print("\n")

            

def Bill_2(custumer_bought, customer_name, Phone_Number, shippping_charge):
            total = 0
            
            for i in custumer_bought:
                total+=int(i[3])
            TotalCost =total
            print("\n")
            print("\t \t \t \t Kamalpokhari International Laptop Centre Bill ")
            print("\n")
            print("\t \t Putalisadak, kathmandu | Phone No: 9802144253")
            print("\n")
            
            print("laptop Details are:")
            print("-------------------------------------------------------------------------")
            print("Customer's Name:"+str(customer_name))
            print("Customer's Phone number: "+str(Phone_Number))
            print("-------------------------------------------------------------------------")
            print("\n")
            print("Details of Purchase:")
            print("------------------------------------------------------------------------------------------------------------------")
            print("Item Name \t\t Total Quantity \t\t Price Unit\t\t\tTotal")
            print("------------------------------------------------------------------------------------------------------------------")
            for i in custumer_bought:
                print(i[0],"\t\t\t",i[1],"\t\t\t",i[2],"\t\t\t","$",i[3])
            print("------------------------------------------------------------------------------------------------------------------")
            if shippping_charge:
                print("Your Shipping Cost is:", shippping_charge)
                print("Grand Total: $"+str(TotalCost))
                print("********Note: Shipping cost is added to the grand total********")
            else:
                print("Grand Total: $"+str(TotalCost))
            print("\n")

def Laptops_Bought(custumer_bought, customer_name, Phone_Number):
        total = 0
        for i in custumer_bought:
            total+=int(i[3])
        TotalCost =total+(0.13 * total)
        print("\n")
        print("\t \t \t \t Kamalpokhari International Laptop Centre Bill ")
        print("\n")
        print("\t \t Putalisadak, kathmandu | Phone No: 9802144253 ")
        print("\n")
        print("-------------------------------------------------------------------------")
        print("Details of laptop are:")
        print("-------------------------------------------------------------------------")
        print("Name of the Distributor:"+str(customer_name))
        print("Distributor's Phone number: "+str(Phone_Number))
        print("-------------------------------------------------------------------------")
        print("\n")
        print("Details of order are:")
        print("------------------------------------------------------------------------------------------------------------------")
        print("Item Name \t\t Total Quantity \t\t Price Unit\t\t\tTotal")
        print("------------------------------------------------------------------------------------------------------------------")
        for i in custumer_bought:
            print(i[0],"\t\t\t",i[1],"\t\t\t",i[2],"\t\t\t","$",i[3])
        print("------------------------------------------------------------------------------------------------------------------")
        print("Your VAT is: 13%")
        print("Grand Total: $"+str(TotalCost))
        print("*********Note: VAT is added to the grand total********")
        print("\n")