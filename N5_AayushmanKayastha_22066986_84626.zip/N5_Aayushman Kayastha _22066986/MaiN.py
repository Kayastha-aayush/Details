from Van.DisplaY import *
from Van.ReaD import *
from Van.ValiD import *
from Van.WritE import *



loop = True
while loop == True:
    Greetings()
    print("-------------------------------------------------------------------------------------------")
    print("Please choose an option from the given below:")
    print("-------------------------------------------------------------------------------------------")
    print("\n")
    print("Press 1 to Sell laptop to the costumer.")
    print("Press 2 to Buy laptop from the manufacturer.")
    print("Press 3 to Exit from the system.")
    print("\n")
    print("-------------------------------------------------------------------------------------------")
    print("\n")
    
    USER_input = int(input("Enter an option to continue: "))
    
    print("\n")

    if USER_input == 1:
        DataofLaptop = Read_Dictionary()
        CustomersName, Phone_Number = Bill_forCustomer()

    
        DisplayingLaptops()

        # Checking if the ID is Vaild or NOT

        Matched_ID = valid_LapID()

        print("\n")



        # checking if  quantity is valid or NOT

        Chosen_Amount = Quantity_Valid(Matched_ID)
        print("\n")

        # Updating the text file

        Changed_Quantity_Laptops(Matched_ID, Chosen_Amount)

        # Getting the user purchased items

        Laptopname = DataofLaptop[Matched_ID][0]
        Selected_quantity = Chosen_Amount
        CosT = DataofLaptop[Matched_ID][2]
        Cost_replacement= DataofLaptop[Matched_ID][2].replace("$",'')
        TotalCost = int(Cost_replacement)*int(Selected_quantity)
        
        BoughtbyUSER = []    
        BoughtbyUSER.append([Laptopname, Selected_quantity, CosT,TotalCost])    
        Shiping = input("Dear user, Do you want to Shipped your laptop?(Y/N)").upper() 
        if Shiping=="Y":
            Bill_1(BoughtbyUSER, CustomersName, Phone_Number)
            Modified_Bill1(BoughtbyUSER, CustomersName, Phone_Number)

        
        else:
            Bill_2(BoughtbyUSER, CustomersName, Phone_Number, Shiping)
            Modified_Bill2(BoughtbyUSER, CustomersName, Phone_Number, Shiping)


    elif USER_input == 2:
        DataofLaptop = Read_Dictionary()
        CustomersName, Phone_Number = Generated_Bills()
    
        DisplayingLaptops()

        Matched_ID = valid_LapID()


        # checking if the  Quantity is valid or NOT

        Chosen_Amount = Quantity_Valid(Matched_ID)

        # Updating the text file

        Updated_Quantity_Laptops(Matched_ID, Chosen_Amount)

        # getting the user purchased items

        Laptopname = DataofLaptop[Matched_ID][0]
        Selected_quantity = Chosen_Amount
        CosT = DataofLaptop[Matched_ID][2]
        Cost_replacement= DataofLaptop[Matched_ID][2].replace("$",'')
        TotalCost = int(Cost_replacement)*int(Selected_quantity)
        
        BoughtbyUSER = []    
        BoughtbyUSER.append([Laptopname, Selected_quantity, CosT,TotalCost])
        
        Laptops_Bought(BoughtbyUSER, CustomersName, Phone_Number)
        Edited_Bill(BoughtbyUSER, CustomersName, Phone_Number)

    elif USER_input == 3:
        loop = False
        print("You have exit  system, Thanks for Visting,Have a good day !")
        print("\n")
    else:
        print("Your option", USER_input,
                "does not seem exist in our system. Please try again. ")
        print("\n")
