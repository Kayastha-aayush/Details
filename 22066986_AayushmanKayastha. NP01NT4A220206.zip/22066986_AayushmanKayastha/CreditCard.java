
/**
 * Write a description of class CreditCard here.
 *
 * @author (Aayush man Kayastha)
 * @version (a version number or a date)
 */
public class CreditCard extends BankCard
{
    private int CVC ;
    private double CreditLimit;
    private double InterestRate;
    private String ExpirationDate;
    private int GracePeriod;
    private boolean IsGranted;
    
    public CreditCard(int CardID, String ClientName, String IssuerBank , String BankAccount , double BalanceAmount , int CVC , double InterestRate , String ExpirationDate)
    {
        super(CardID , IssuerBank , BalanceAmount , BankAccount);
        this.CVC = CVC;
        this.InterestRate = InterestRate;
        this.ExpirationDate = ExpirationDate;
        this.IsGranted = false;
    }
    
    //Acessor method
    
    public int getCVC()
    {
        return CVC;
    }
    
    public double getCreditLimit()
    {
        return CreditLimit;
    }
    
    public double getInterestRate()
    {
        return this.InterestRate;
    }
    
    public String getExpirationDate()
    {
        return ExpirationDate;
    }
    
    public int getGracePeriod()
    {
        return GracePeriod;
    }
    
    public boolean getIsGranted()
    {
        return IsGranted;
    }
    
    public void setCreditLimit(double CreditLimit)
    {
        this.CreditLimit = CreditLimit;
    }
    
    public void setInterestRate (double InterestRate)
    {
        this.InterestRate = InterestRate;
    }
    
    public void setExpirationDate (String ExpirationDate)
    {
        this.ExpirationDate = ExpirationDate;
    }
    
    public void setGracePeriod(int GracePeriod)
    {
        this.GracePeriod = GracePeriod;
    }
    
    //setters method
    public void setCreditLimit(double CreditLimit , int GracePeriod)
    {
        if((super.getBalanceAmount()*2.5)>=CreditLimit)
        {
        this.IsGranted = true;
        this.CreditLimit = CreditLimit;
        this.GracePeriod = GracePeriod;
        }
        else
        {
            System.out.println("You dont have sufficient balance. ");
        }
    }
    
    public void CancelCreditCard() 
    {
        this.CVC = 0;
        this.CreditLimit = 0;
        this.GracePeriod = 0;
        this.IsGranted = false;
    }
    
    //Display Method
    public void display()
    {
        super.Display();
        if(this.IsGranted == true)
        {
            System.out.println("CreditLimit :");
            System.out.println("Grace Period :");
        }
    }
}
