
/**
 * Write a description of class DebitCard here.
 *
 * @author (Aayush man Kayastha)
 * @version (a version number or a date)
 */
public class DebitCard extends BankCard
{
    private int PIN;
    private int WithdrawalAmount;
    private String DateOfWithdrawal;
    private boolean HasWithdrawn;
    
    // Constructor
    public DebitCard(int PIN , int CardID , String BankAccount , String ClientName ,String IssuerBank ,double BalanceAmount)
    {
        super(CardID ,BankAccount ,BalanceAmount ,IssuerBank );
        this.PIN = PIN;
        super.setClientName(ClientName);
        this.HasWithdrawn = false;
    }
    
    //getters method
    public int getPIN()
    {
        return this.PIN; 
    }
    
    public int getWithdrawalAmount()
    {
        return this.WithdrawalAmount;
    }
    
    public String getDateOfWithdrawal()
    {
        return this.DateOfWithdrawal;
    }
    
    public boolean getHasWithdrawn()
    {
        return this.HasWithdrawn;
    }
    
    //mutators method
    public void setWithdrawalAmount(int WithdrawalAmount)
    {
        this.WithdrawalAmount = WithdrawalAmount;
    }
    
    //withdraw method
    public void withdraw (int WithdrawalAmount , String DateOfWithdraw , int PIN)
    {   
        double BalanceAmount = super.getBalanceAmount();
        if (this.PIN == PIN && WithdrawalAmount <= BalanceAmount)
        {
            this.setWithdrawalAmount(WithdrawalAmount);
            this.DateOfWithdrawal = DateOfWithdraw;
            this.HasWithdrawn = true;
            super.setBalanceAmount(BalanceAmount - WithdrawalAmount);
        }
        else if(this.PIN != PIN)
        {
            System.out.println("Incorrect PIN");
        }
        else if(BalanceAmount < WithdrawalAmount)
        {
            System.out.println("No Sufficient Balance");
        }
    }
    
    public void Display()
        {
            if (this.HasWithdrawn==true) 
            {
                System.out.println("PIN number = " +PIN);
                System.out.println("WithdrawalAmount =" +WithdrawalAmount);
                System.out.println("DateOfWithdrawal ="+DateOfWithdrawal);
            }
            else 
            {
                System.out.println("BalanceAmount");    
            }
        }
    }
