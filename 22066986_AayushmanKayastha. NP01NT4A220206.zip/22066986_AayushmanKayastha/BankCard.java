
/**
 * Write a description of class BankCard here.
 *
 * @author (Aayush man Kayastha)
 * @version (a version number or a date)
 */
public class BankCard
{
    private int CardID ;
    private double BalanceAmount;
    private String IssuerBank ;
    private String ClientName ;
    private String BankAccount;
    
    //Constructor is written inside()
    public BankCard(int CardID , String BankAccount ,double BalanceAmount ,String IssuerBank)
    {
        this.CardID = CardID;
        this.BankAccount = BankAccount;
        this.BalanceAmount = BalanceAmount;
        this.IssuerBank = IssuerBank;
        this.ClientName = "";
    }
    
    // getters method
    public int getCardID()
    {
        return this.CardID;
    }
    
    public String getBankAccount()
    {
        return this.BankAccount;
    }
    
    public double getBalanceAmount()
    {
        return this.BalanceAmount;
    }
    
    public String getIssuerBank()
    {
        return this.IssuerBank;
    }
    
    public String getClientName()
    {
        return this.ClientName;
    }
    
    // setters method
    public void setClientName(String name)
    {
        this.ClientName = name;
    }
    
    public void setBalanceAmount(double Balance)
    {
        this.BalanceAmount = Balance;
    }
    
    public void Display()
    {
        System.out.println("CardID =" +this.CardID);
        System.out.println("IssuerBank =" +this.IssuerBank);
        System.out.println("BankAccount =" +this.BankAccount);
        System.out.println("BankAmount =" +this.BalanceAmount);
        if (ClientName == "")
        System.out.println ("Client name is not assigned ");
        else
        System.out.print ("Client name =" + this.ClientName);
    }
}


